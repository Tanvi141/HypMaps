# HypMaps
Python package to map points from Euclidean to Hyperbolic space.
The only dependency is numpy
